#include <iostream>
#include "Car.h"
#include "Road.h"
#include <queue>
using namespace std;
void efficiency(Road r) {
	float max = 0;
	if (r.getcountA() > max) { max = r.getcountA(); }
	if (r.getcountB() > max) { max = r.getcountB(); }
	if (r.getcountC() > max) { max = r.getcountC(); }
	float eff;
	eff = (r.getcountA() / max) * 100.00;
	cout << "Efficiency of road A is: " << eff<<"%"<<endl;
	eff = (r.getcountB() / max) * 100.00;
	cout << "Efficiency of road B is: " << eff << "%" << endl;
	eff = (r.getcountC() / max) * 100.00;
	cout << "Efficiency of road C is: " << eff << "%" << endl;
}

void main() {
	int n;
	cout << "How many  vehicles would like to enter?" << endl;
	cin >> n;
	Car* arr;
	arr = new Car[n];
	string ans;
	int anss;
	for (int i = 0; i < n; i++) {
		cout << "Enter detials for vehicle number: " << i + 1 << endl;
		cout << "What is the brand: ";
		cin >> ans;
		arr[i].setbrand(ans);
		cout << "What is the vehicle type: ";
		cin >> ans;
		arr[i].settype(ans);
		cout << "What is the " << arr[i].gettype() << " plate number: ";
		cin >> ans;
		arr[i].setplate(ans);
		cout << "What is the vehicles speed: ";
		cin >> anss;
		arr[i].setspeed(anss);
		cout << "What is the vehicles year model: ";
		cin >> anss;
		arr[i].setyear(anss);
	}
	queue<Car> q;
	for (int i = 0; i < n; i++) {
		q.push(arr[i]);
	}
	Road r;
	int y = 1;
	while (!(q.empty())) {
		bool x = false;
		cout << "Starting with Vehicle number: " << y << endl;
		r.allow(q.front().gettype());
		x = r.radar(q.front().getspeed(), r.getrt());
		if (x) {
			cout << "This vehicle will be fined" << endl;
			cout << "Vehicle details are as follows: " << endl;
			cout << " Brand: " << q.front().getbrand() << endl;
			cout << " Type: " << q.front().gettype() << endl;
			cout << " Plate: " << q.front().getplate() << endl;
			cout << " Speed: " << q.front().getspeed() << endl;
			cout << " Year model: " << q.front().getyear() << endl;
		}
		cout << "The age of vehicle number " << y<<" is: ";
		cout << r.age(q.front().getyear()) << endl;
		q.pop();
		y++;
	}
	efficiency(r);
}
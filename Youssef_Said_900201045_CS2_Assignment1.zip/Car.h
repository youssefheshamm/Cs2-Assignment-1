#pragma once
#include <iostream>
using namespace std;

class Car {
private:
	string Car_brand;
	string Car_type;
	string Car_plate;
	int speed;
	int year_model;
public:
	Car() {
		Car_brand = " ";
		Car_type = " ";
		Car_plate = " ";
		speed = 0;
		year_model = 0;
	};
	Car(string cb, int ms, int ym) {
		Car_brand = cb;
		speed = ms;
		year_model = ym;
	}
	void setbrand(string s) {
		Car_brand = s;
	}
	void settype(string t) {
		Car_type = t;
	}
	void setplate(string p) {
		Car_plate = p;
	}
	void setspeed(int s) {
		speed = s;
	}
	void setyear(int ym) {
		year_model = ym;
	}
	string getbrand() {
		return Car_brand;
	}
	string gettype() {
		return Car_type;
	}
	string getplate() {
		return Car_plate;
	}
	int getspeed() {
		return speed;
	}
	int getyear() {
		return year_model;
	}
};
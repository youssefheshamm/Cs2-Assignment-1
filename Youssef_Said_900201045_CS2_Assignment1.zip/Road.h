#pragma once
#include <iostream>
#include <queue>
#include <cctype>
using namespace std;

class Road {
private:
	char Road_type;
	int speed_limit;
	float countA, countB, countC;
public :
	Road() {
		Road_type = ' ';
		speed_limit = 0;
		countA = 0;
		countB = 0;
		countC = 0;
	}
	Road(char rt, int sl) {
		Road_type = rt;
		speed_limit = sl;
	}
	void settype(int rt) {
		Road_type = rt;
	}
	void setcountA(int x) {
		countC = x;
	}
	void setcountB(int x) {
		countB = x;
	}
	void setcountC(int x) {
		countC = x;
	}
	char getrt() {
		return Road_type;
	}
	int getspeedlimit() {
		return speed_limit;
	}
	int getcountA() {
		return countA;
	}
	int getcountB() {
		return countB;
	}
	int getcountC() {
		return countC;
	}
	bool radar(int cs, char rt) {
		toupper(rt);
		if (rt == 'A') {
			speed_limit = 80;
		}
		if (rt == 'B') {
			speed_limit = 50;
		}
		if (rt == 'C') {
			speed_limit = 40;
		}
		if (cs > speed_limit) {
			return true;
		}
		return false;
	}
	void allow(string car_type) {
		bool a= false, c= false;
		cout << "Road A: allows only Private and motorcycle vehicles" << endl;
		cout << "Road B: allows ALL vehicles" << endl;
		cout << "Road C: allows only Private trucks" << endl;
		if ((car_type == "Private") || (car_type == "motorcycle")) {
			a = true;
		}
		else if (car_type == "truck") {
			c = true;
		}
		else {
			cout << "You are only allowed on road B" << endl;
			Road_type = 'B';
			countB++;
			return;
		}
		if (a) {
			cout << "You are allowed to go on road A and B" << endl;
			cout << "Please choose only one: ";
			char choice;
			cin >> choice;
			toupper(choice);
			while ((choice != 'A') && (choice != 'B')) {
				cout << "Invalid choice, try again" << endl;
				cin >> choice;
			}
			if (choice == 'A') { countA++; }
			if (choice == 'B') { countB++; }
			Road_type = choice;
		}
		if (c) {
			cout << "You are allowed to go on road C and B" << endl;
			cout << "Please choose only one: ";
			char choice2;
			cin >> choice2;
			toupper(choice2);
			while ((choice2 != 'C') && (choice2 != 'B')) {
				cout << "Invalid choice, try again" << endl;
				cin >> choice2; 
			}
			if (choice2 == 'C') { countC++; }
			if (choice2 == 'B') { countB++; }
			Road_type = choice2;
		}
		
	}
	int age(int ym) {
		return (2022 - ym);
	}

};